# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'untitledSUHJTR.ui'
##
## Created by: Qt User Interface Compiler version 6.7.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QMainWindow, QProgressBar, QSizePolicy, QWidget)

class ui_progress(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(680, 400)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.horizontalLayout = QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(10, 10, 10, 10)
        self.dropshadowframe = QFrame(self.centralwidget)
        self.dropshadowframe.setObjectName(u"dropshadowframe")
        self.dropshadowframe.setStyleSheet(u"QFrame{\n"
"background-color:rgb(56,58,89);\n"
"color:rgb(220,220,220);\n"
"border-radius:10px;\n"
"}")
        self.dropshadowframe.setFrameShape(QFrame.Shape.StyledPanel)
        self.dropshadowframe.setFrameShadow(QFrame.Shadow.Raised)
        self.label_title = QLabel(self.dropshadowframe)
        self.label_title.setObjectName(u"label_title")
        self.label_title.setGeometry(QRect(10, 89, 641, 71))
        font = QFont()
        font.setPointSize(40)
        self.label_title.setFont(font)
        self.label_title.setStyleSheet(u"color:rgb(254,121,199);")
        self.label_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_description = QLabel(self.dropshadowframe)
        self.label_description.setObjectName(u"label_description")
        self.label_description.setGeometry(QRect(10, 150, 641, 31))
        font1 = QFont()
        font1.setPointSize(14)
        self.label_description.setFont(font1)
        self.label_description.setStyleSheet(u"color:rgb(98,114,168);")
        self.label_description.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.progressBar = QProgressBar(self.dropshadowframe)
        self.progressBar.setObjectName(u"progressBar")
        self.progressBar.setGeometry(QRect(40, 270, 581, 21))
        self.progressBar.setStyleSheet(u"QProgressBar{\n"
"	background-color:rgb(98,115,164);\n"
"	color:rgb(200,200,200);\n"
"	border-style:none;\n"
"border-radius:10px;\n"
"text-align:center;\n"
"}\n"
"QProgressBar::chunk{\n"
"	border-radius:10px;\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.511364, x2:1, y2:0.523, stop:0 rgba(254, 121, 199, 255), stop:1 rgba(170, 85, 255, 255));\n"
"};")
        self.progressBar.setValue(24)
        self.label_3 = QLabel(self.dropshadowframe)
        self.label_3.setObjectName(u"label_loading")
        self.label_3.setGeometry(QRect(10, 300, 641, 31))
        font2 = QFont()
        font2.setPointSize(12)
        self.label_3.setFont(font2)
        self.label_3.setStyleSheet(u"color:rgb(98,114,168);")
        self.label_3.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_credits = QLabel(self.dropshadowframe)
        self.label_credits.setObjectName(u"label_credits")
        self.label_credits.setGeometry(QRect(10, 351, 641, 31))
        font3 = QFont()
        font3.setPointSize(10)
        self.label_credits.setFont(font3)
        self.label_credits.setStyleSheet(u"color:rgb(98,114,168);")
        self.label_credits.setAlignment(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignTrailing|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout.addWidget(self.dropshadowframe)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_title.setText(QCoreApplication.translate("MainWindow", u"<strong>AI</strong> Broker", None))
        self.label_description.setText(QCoreApplication.translate("MainWindow", u"<strong>Ghar</strong> Lo <strong>Ghar</strong> Do", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"loading", None))
        self.label_credits.setText(QCoreApplication.translate("MainWindow", u"<strong>Created : </strong>Shivam M. Chavan", None))
    # retranslateUi

